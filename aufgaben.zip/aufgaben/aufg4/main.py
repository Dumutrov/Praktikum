from random import randint, shuffle
a = []
length = 10
for i in range(length):
	a.append(range(length))	
	a[i] = randint(0,100)
print a

shuffle(a)
print a
