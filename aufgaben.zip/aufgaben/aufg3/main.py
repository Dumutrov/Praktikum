def euklid(a, b):
	if b == 0:
		return a	
	elif a == 0:
		return b
	elif a > b:
		return euklid(a - b, b)
	else:
		return euklid(a, b - a)

print euklid(50, 60)
