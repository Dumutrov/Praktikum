from random import randint, shuffle
unsorted = []
length = 10000
for i in range(length):
	unsorted.append(range(length))	
	unsorted[i] = randint(0,100000)
shuffle(unsorted)

def insertionSort(list):
	for index in range(1,len(list)):
		value = list[index]
		i = index - 1
		while i>=0:
			if value < list[i]:
				list[i+1] = list[i]
				list[i] = value
				i -= 1
			else:
				break

print "Unsortiert: ", unsorted, "\n"				
insertionSort(unsorted)
print "Sortiert: ", unsorted