# Bubblesort
from random import randint
length = 10000

# create list of random ints
unsorted = []
for i in range(length):
    unsorted.append(randint(0,100000))
sortedlst = []
print (unsorted)
print (len(unsorted))

def bubblesort(lst):  
    for a in range(len(lst)):
		for i in range(len(lst)-1):
			if lst[i] > lst[i+1]: # check if first element is bigger than second
				tmp = lst[i]
				lst[i] = lst[i+1]
				lst[i+1] = tmp
bubblesort(unsorted)
print (unsorted)