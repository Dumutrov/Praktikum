num = input("Number to check: ")

if num > 1:
	for i in range(2, num):
		if num % i == 0:
			print(num, "ist keine Primzahl")
			break
		else:
			print(num, "ist eine Primzahl")
else:
	print("Die Zahl muss groesser, als 1 sein.")
