inputfile = open("/home/lukas/aufgaben/aufg10/text.txt" , "r")

words = ['']
letters = ['']

#split to tokens
for lines in inputfile:
	splittedWords = lines.split()	
	words.append(splittedWords)
print words

#split to char
words = str(words)
for letter in words:
	letters.append(letter)
#print letters

letterCount = 0
for i in letters:
	if i == "e":
		letterCount += 1
print "Es ist",letterCount, "mal das 'e' vorgekommen."

#count vocals
for i in letters:
	if i == "a":
		letterCount += 1
	elif i == "e":
		letterCount += 1
	elif i == "i":
		letterCount += 1
	elif i == "o":
		letterCount += 1
	elif i == "u":
		letterCount += 1
print "Es sind",letterCount,"Vokale im Text vorhanden."

print len(words)
# most common word
counter = {}
maxItemCount = 0
for item in words:
	try:
		counter[item]
		counter[item] += 1
	except KeyError:
		counter[item] = 1
	if counter[item] > maxItemCount:
		maxItemCount = counter[item]
		mostCommonItem = item

print "Haeufigstes Wort: ", mostCommonItem
