# -*- coding: utf-8 -*-
import codecs, collections
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

matchedWords = {}
allWords = {}
with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dump.txt", "r", "UTF-8") as inputfile:
	with codecs.open("/home/lukas/aufgaben/dictionarySort/unlogischeVerben.txt","w","UTF-8") as unusable:
		with codecs.open("/home/lukas/aufgaben/dictionarySort/logischeVerben.txt", "w", "UTF-8") as usable:		
			praefixeBACK = ["ab","an","aus","bei","dar","dran","durch","ein","ent","fort","frei","her","hin","hoch","mit","nach","tief","um","ver","weg","zer","zu","lich","zurück","zufrieden","bereit", "vor", "auf","recht","Recht","satt","herein","entgegen","entzwei","Liebe"]
			praefixeFRONT = ["ab","an","aus","bei","dar","dran","durch","ein","fort","frei","her","hin","hoch","mit","nach","tief","um","weg","zer","zu","lich","zurück","zufrieden","bereit", "vor", "auf","recht","Recht","satt","herein","entgegen","entzwei","Liebe"]
			unwanted = ["0","1","2","3","4","5","6","7","8","9","!",'\"',"$","%","&","/","(",")","=","?","{","}",",","\\","|","<",">","-","_",":",".",",","#","+","/","*","^","{{CH&amp;LI}}","\'"]
			# not trackable: §, €, °, ´, `, phonetic alphabet
			for line in inputfile:
				allWords[line] = line
				line = line.strip("\n")
				words = line.split(";")
				outptln = ""
				unwantedChar = False
				# check if unwanted characters exist
				for item in unwanted:
					for word in words:
						if item in word:
							unwantedChar = True
							outputline = line
				
				lineMatch = False
				faselMatch = False
				newWord = ""
				outputline = ""
				usableOutput = ""
				unusableOutput = ""
				splittedWord = ""
				oldLine = ""
				words = line.split(";")# split lines into words
				for word in words:
					# Check for "[" or "]"
					if "[" in word or "]" in word:
						word = word.replace("[", "")
						word = word.replace("]", "")
					outptln += word + ";"
					### word ist hier gefixt (ohne [ ])
					# check if one praefix is at the end of any word

					if not len(word) == 0:
						for item in praefixeBACK: # item = elements of praefixe
							if item == word[-len(item):]:
								lineMatch = True # line matches
							
				
				for word in words[:1]: # iterate over first word in every line
					for item in praefixeFRONT:
						if item == word[0:len(item)]: # find words with a praefix at the beginning
							newWord = str(word.split(item)) # newWord ist der Substantiv ohne Präfix
							#print "word: ", word, "\t", item, "\t\tnewWord: ", newWord
							matchedWords[word] = line + "\t" + newWord
				# check if one word appears more than once in each line
				### Most of the words will be declared as wrong, because many words 
				### appear twice or more in one line
					
					# outptline = ""
					# multipleStrings = False
					# multipleStrings2 = False
					# for word, cnt in collections.Counter(words).most_common():
						# if cnt > 1:
							# multipleStrings = True
							# multipleStrings2 = True
							# word = "DOPPELT"
						# if(multipleStrings):
							# outptline += word + ";"
						# else:
							# outputline += word + ";"
							
				# if (multipleStrings2):
					# unusable.write("Ein Wort kommt mehrfach vor:   \t" + line + "\n")
				if (lineMatch):
					for matchValue in matchedWords.itervalues(): # iterate over dict
						oldLine = matchValue.split("\t")[0] # oldLine "abbrechen;brichstab;brecheab"
						matchValue = matchValue.split("\t")[1]
						matchValue = matchValue.strip("[u'', u'")
						matchValue = matchValue.strip("']") # value "brechen"
						for wordValue in allWords.itervalues():
							if matchValue in wordValue:
								#print matchValue, "in ", wordValue
								faselMatch = True
				if (unwantedChar):
					unusable.write("Ungewollte/s Zeichen gefunden:\t" + line + "\n")
				elif(faselMatch):
					unusable.write("FASEL: " + oldLine + "\n")
					#unusable.write("unlogische Form/en:            \t" + line + "\n")
				else:
					usable.write("TEST: " + line + "\n")
					
# Präfixe die von Präpositionen abstammen, werden meistens nicht abgespalten
# Präfixe die nicht von Präpositionen abstammen, werden meistens abgespalten