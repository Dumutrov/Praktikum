# -*- coding: utf-8 -*-
import codecs

with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dump.txt", "r", "UTF-8") as inputfile:
	praefixe = ["ab","an","aus","be","bei","dar","dran","durch","ein","ent","er","fort","frei","ge","her","hin","hoch","mit","nach","tief","um","ver","weg","zer","zu","lich","zurück"]
	lst = ["0","1","2","3","4","5","6","7","8","9","!",'"',"$","%","&","/","(",")","=","?","{","}","[","]","\\","|","<",">","-","_",":",".",",","#","+","/","*","^"]
	#not trackable: §, €, °, ´, `, phonetic alphabet
	for line in inputfile:
		words = line.split(";")
		
		# check if one word is simillar to another word that's not at index 1
		for i in range(len(words)):
			if words[i] in words[1+i:]:
				print "more than once:", words[i] # prints words that appear more than once in one line
		
		# check if unwanted characters exist
		for item in lst:
			for word in words:
				if item in word:
					print item, "in", word
		
		# check for nouns
		for word in words:
			if word.istitle():
				print "Noun:", word
		
		
		# check if one praefix is at the end of any word
		printfasel = ""
		match = False
		words = line.split(";")# split lines into words
		for item in praefixe: # item = elements of praefixe
			for word in words:
				if item == word[-len(item):]:
					print item
					print word
					print "\n"
					printfasel += "BLUBB;"
					match = True
				else:
					printfasel += word + ";"
		if (match):
			with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dumpOUTPUT.txt","a","UTF-8") as outputfile:
				outputfile.write(printfasel)

# Präfixe die von Präpositionen abstammen, werden meistens nicht abgespalten
# Präfixe die nicht von Präpositionen abstammen, werden meistens abgespalten