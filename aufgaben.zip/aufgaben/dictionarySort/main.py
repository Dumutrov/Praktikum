# -*- coding: utf-8 -*-
import codecs

with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dump.txt", "r", "UTF-8") as inputfile:
	with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dumpOUTPUT.txt","w","UTF-8") as outputfile:
		praefixe = ["ab","an","aus","be","bei","dar","dran","durch","ein","ent","er","fort","frei","ge","her","hin","hoch","mit","nach","tief","um","ver","weg","zer","zu","lich","zurück"]
		lst = ["0","1","2","3","4","5","6","7","8","9","!",'"',"$","%","&","/","(",")","=","?","{","}","\\","|","<",">","-","_",":",".",",","#","+","/","*","^"]
		# not trackable: §, €, °, ´, `, phonetic alphabet
				
		for line in inputfile:
			line = line.strip("\n")
			words = line.split(";")
			
			# check if one word appears more than once in the line
			for i in range(len(words)):
				if words[i] in words[1+i:]:
					pass
					#print "more than once:", words[i]
			
			# Check for [ and ]
			bracketMatch = False
			for word in words:
				if "[" in word or "]" in word:
					bracketMatch = True
					word.replace("[", "")
					word.replace("]", "")
			if (bracketMatch):
				outputfile.write(word + ";")
			
			# check if unwanted characters exist
			for item in lst:
				for word in words:
					if item in word:
						outputline = "BLA"
						outputfile.write(outputline + "\n")
						#print item, "in", word

			
			# check for nouns
			for word in words:
				if word.title():
					pass
					#print "Noun:", word
			
			
			# check if one praefix is at the end of any word

			lineMatch = False
			outputline = ""
			words = line.split(";")# split lines into words
			for word in words:
				wordMatch = False
				if not len(word) == 0: 
					for item in praefixe: # item = elements of praefixe
						if item == word[-len(item):]:
							wordMatch = True # word matches
							lineMatch = True # line matches
							print item
							print word
							print "\n"
					if(wordMatch):
						outputline += "BLUBB;"
						print outputline
					else:
						outputline += word + ";"
						print outputline
			
			if (lineMatch):
				outputfile.write(outputline + "\n")

	# Präfixe die von Präpositionen abstammen, werden meistens nicht abgespalten
	# Präfixe die nicht von Präpositionen abstammen, werden meistens abgespalten