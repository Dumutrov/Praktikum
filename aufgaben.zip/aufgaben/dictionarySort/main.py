# -*- coding: utf-8 -*-
import codecs, collections
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

matchedWords = {}

with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dump.txt", "r", "UTF-8") as inputfile:
	with codecs.open("/home/lukas/aufgaben/dictionarySort/unlogischeVerben.txt","w","UTF-8") as unusable:
		with codecs.open("/home/lukas/aufgaben/dictionarySort/logischeVerben.txt", "w", "UTF-8") as usable:		
			praefixe = ["ab","an","aus","bei","dar","dran","durch","ein","ent","fort","frei","her","hin","hoch","mit","nach","tief","um","ver","weg","zer","zu","lich","zurück","zufrieden","bereit", "vor", "auf","recht","Recht","satt","herein"]
			unwanted = ["0","1","2","3","4","5","6","7","8","9","!",'\"',"$","%","&","/","(",")","=","?","{","}",",","\\","|","<",">","-","_",":",".",",","#","+","/","*","^","{{CH&amp;LI}}","\'"]
			# not trackable: §, €, °, ´, `, phonetic alphabet
			for line in inputfile:
				line = line.strip("\n")
				words = line.split(";")
				outptln = ""
				unwantedChar = False
				# check if unwanted characters exist
				for item in unwanted:
					for word in words:
						if item in word:
							unwantedChar = True
							outputline = line
				
				lineMatch = False
				newMatch = False
				newWord = ""
				outputline = ""
				splittedWord = ""
				words = line.split(";")# split lines into words
				for word in words:
					# Check for "[" or "]"
					if "[" in word or "]" in word:
						word = word.replace("[", "")
						word = word.replace("]", "")
					outptln += word + ";"
					### word ist hier gefixt (ohne [ ])
					# check if one praefix is at the end of any word
					wordMatch = False

					if not len(word) == 0:
						for item in praefixe: # item = elements of praefixe
							if item == word[-len(item):]:
								lineMatch = True # line matches
							
							if item == word[0:len(item)]:
								newWord = str(word.split(item)) # newWord ist der Substantiv ohne Präfix
								matchedWords[word] = newWord
								#print "word: ", word, "\t", item, "\t\tnewWord: ", newWord		
							
				
				# check if one word appears more than once in each line
				### Most of the words will be declared as wrong, because many words 
				### appear twice or more in one line
					
					# outptline = ""
					# multipleStrings = False
					# multipleStrings2 = False
					# for word, cnt in collections.Counter(words).most_common():
						# if cnt > 1:
							# multipleStrings = True
							# multipleStrings2 = True
							# word = "DOPPELT"
						# if(multipleStrings):
							# outptline += word + ";"
						# else:
							# outputline += word + ";"
							
				# if (multipleStrings2):
					# unusable.write("Ein Wort kommt mehrfach vor:   \t" + line + "\n")
				
				
				
				if (lineMatch):
					unusable.write("unlogische Form/en:            \t" + line + "\n")
				elif (unwantedChar):
					unusable.write("Ungewollte/s Zeichen gefunden:\t"+ line + "\n")
				else:
					usable.write(outptln + "\n")
					
					### WIP
					"""
					for item in matchedWords:
						if item in words:
							print "matchedWords: ", item, "word: ", word 
					"""
				
				
				# if (newMatch):
					# usable.write(output + "\n")
				
# Präfixe die von Präpositionen abstammen, werden meistens nicht abgespalten
# Präfixe die nicht von Präpositionen abstammen, werden meistens abgespalten