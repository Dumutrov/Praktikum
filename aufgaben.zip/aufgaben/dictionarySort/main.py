# -*- coding: utf-8 -*-

import codecs

with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dump.txt", "r", "UTF-8") as inputfile:
	for line in inputfile:
		if "[" or "]" in line:
			line = line.replace("[", "")
			newStr = line.replace("]", "")
			#print "\n"
			#print line
			#print newStr
	print "rdy"

# Präfixe die von Präpositionen abstammen, werden meistens nicht abgespalten
# Präfixe die nicht von Präpositionen abstammen, werden meistens abgespalten
praefixe = ["ab","an","aus","be","bei","dar","dran","durch","ein","ent","er","fort","frei","ge","her","hin","hoch","mit","nach","tief","um","ver","weg","zer","zu"]
lst = []

test = 0

with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dump.txt", "r", "UTF-8") as inputfile:
	for line in inputfile:
		if (test < 10):
			printfasel = ""
			match = False
			words = line.split(";")# split lines into words
			for item in praefixe: # item = elements of praefixe
				for word in words:
					if item == word[-len(item):]:
						print item
						print word
						print "\n"
						with codecs.open("/home/lukas/aufgaben/dictionarySort/parsed_verbs_dumpOUTPUT.txt","a","UTF-8") as outputfile:
							outputfile.write(line.replace(word, "BLUBB"))
							printfasel += word
							match = True
					else:
						printfasel += "line"
				if (match):
					outputfile.write(printfasel(TODO))
		test+=1