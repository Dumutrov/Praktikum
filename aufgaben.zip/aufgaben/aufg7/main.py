from string import maketrans
a = maketrans("ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz", 
    "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm")

toTranslate = "Qvrf vfg rva xyrvare Hrohatfgrkg. Fpurvaone unfg qh vua rebytervpu ragfpuyhrffryg. Oenib"
print toTranslate.translate(a)
