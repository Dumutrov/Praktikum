def example():
	inpt = int(raw_input("Zahl eingeben "))
	inpt += 1
	print inpt

example()
