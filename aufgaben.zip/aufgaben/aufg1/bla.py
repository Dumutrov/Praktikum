inputfile = open("/home/lukas/aufgaben/aufg1/input.txt", "r")
outputfile = open("/home/lukas/aufgaben/aufg1/output.txt", "w")
count = 0
count1 = 0
for line in inputfile:
	count += 1
	if count % 2 == 0:	
		print line
	else:
		outputfile.write(line)
