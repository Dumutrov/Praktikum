from random import randint
import os
inputfile = open("/home/lukas/aufgaben/aufg11/inputdata.txt","r")

# function to clear the console
def cls():
    os.system('cls' if os.name=='nt' else 'clear')

words = []
for line in inputfile:
	words.append(line)
ran = randint(0,19)
choice = words[ran]

# count length of word
lengthOfWord = 0
for i in range(1, len(choice)):
	lengthOfWord += 1

# encrypt to underscores
underscore = []
for i in range(lengthOfWord):
	underscore.append("_")

print underscore

# creating a list of choice to compare the underscore-array with choice
choiceList = []
for char in choice:
	choiceList += char
choiceList.pop()

finished = bool(0)
count = 0
while not finished:

	# check if every character is guessed		
	if underscore == choiceList:
		finished = bool(1)		
		print "Wort erraten."
		break		
	
	# read user input	
	userInput = raw_input("Buchstabe eingeben: ")	
	if not userInput == "":
		count += 1	
	# replace underscore with guessed character
	for i in range(len(choice)):
		if userInput == choice[i]:
			print "Eingabe stimmt mit einem der Buchstaben  ueberein."
			underscore[i] = userInput
	cls()	
	print underscore
	print "Versuche: ",count
	
	
